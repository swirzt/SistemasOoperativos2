#ifndef NACHOS_THREADS_SYS_INFO__HH
#define NACHOS_THREADS_SYS_INFO__HH


void SysInfo();


#endif
